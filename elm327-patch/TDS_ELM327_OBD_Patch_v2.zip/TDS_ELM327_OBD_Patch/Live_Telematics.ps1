# =============================================================================
# Tata Diagnostic System (TDS) - Live CAN Bus & Connection Monitor
# =============================================================================
[CmdletBinding()]
param(
    [string]$JsonPath = "",
    [int]$RefreshRateMs = 125,
    [switch]$SingleShot = $false
)

if ([string]::IsNullOrEmpty($JsonPath)) {
    $base = if (![string]::IsNullOrEmpty($PSScriptRoot)) { $PSScriptRoot } else { (Get-Location).Path }
    $JsonPath = Join-Path $base "live_telematics.json"
}

try {
    $Host.UI.RawUI.WindowTitle = "Tata Diagnostic System - Live CAN Bus Monitor"
} catch { }

$hasConsole = $false
try {
    $hasConsole = (-not [Console]::IsOutputRedirected) -and ($Host.Name -match "Console")
    if ($hasConsole) {
        [Console]::CursorVisible = $false
    }
} catch {
    $hasConsole = $false
}

if ($hasConsole) {
    try { Clear-Host } catch { }
}

try {
    $running = $true
    $spinChars = @('|', '/', '-', '\')
    $spinIdx = 0

    while ($running) {
        # Check for user exit (Q / Esc)
        try {
            if (-not [Console]::IsInputRedirected -and [Console]::KeyAvailable) {
                $key = [Console]::ReadKey($true)
                if ($key.Key -eq [ConsoleKey]::Q -or $key.Key -eq [ConsoleKey]::Escape) {
                    break
                }
            }
        } catch { }

        $spinner = $spinChars[$spinIdx % $spinChars.Length]
        $spinIdx++

        $data = $null
        if (Test-Path $JsonPath) {
            try {
                $raw = Get-Content -Path $JsonPath -Raw -ErrorAction SilentlyContinue
                if (-not [string]::IsNullOrEmpty($raw)) {
                    $data = ConvertFrom-Json $raw -ErrorAction SilentlyContinue
                }
            } catch { }
        }

        if ($hasConsole) {
            try {
                [Console]::SetCursorPosition(0, 0)
            } catch {
                Clear-Host
            }
        }

        Write-Host "================================================================================" -ForegroundColor Cyan
        Write-Host "         TATA MOTORS DIAGNOSTIC SYSTEM - LIVE CAN BUS MONITOR           " -ForegroundColor Yellow -NoNewline
        Write-Host "[$spinner]" -ForegroundColor White
        Write-Host "================================================================================" -ForegroundColor Cyan

        if ($null -eq $data) {
            Write-Host "  Waiting for Tata Diagnostic System and ELM327 bridge to communicate...        " -ForegroundColor Gray
            Write-Host "  Launch TDS with Start_TDS_ELM327.bat or connect vehicle OBD2 port.            " -ForegroundColor DarkGray
            Write-Host ""
            for ($k = 0; $k -lt 16; $k++) { Write-Host (" " * 80) }
            if ($SingleShot) { break }
            Start-Sleep -Milliseconds 250
            continue
        }

        # 1. Connection & Hardware Status
        $connType = if ($data.connectionType) { $data.connectionType } else { "DISCONNECTED" }
        $endpoint = if ($data.endpoint) { $data.endpoint } else { "None" }
        $isHw = [bool]$data.isHardwareConnected

        Write-Host " Connection: " -NoNewline
        if ($isHw) {
            Write-Host "ONLINE (CONNECTED)          " -ForegroundColor Green -NoNewline
        } else {
            Write-Host "STANDBY / READY             " -ForegroundColor Yellow -NoNewline
        }
        Write-Host " | Interface: " -NoNewline
        if ($connType -eq "WIFI") {
            Write-Host ("WiFi TCP ({0})" -f $endpoint) -ForegroundColor Green
        } elseif ($connType -eq "SERIAL") {
            Write-Host ("Serial ({0})" -f $endpoint) -ForegroundColor Green
        } else {
            Write-Host ("{0} ({1})" -f $connType, $endpoint) -ForegroundColor Yellow
        }

        # 2. Target ECU & Diagnostic Bus Stats
        $ecuId = if ($data.activeEcuId) { $data.activeEcuId } else { "0x7EB" }
        $ecuName = if ($data.activeEcuName) { $data.activeEcuName } else { "Vehicle ECU" }
        $lat = [int]$data.latencyMs
        $tx = [long]$data.totalTxPackets
        $rx = [long]$data.totalRxPackets

        Write-Host " Target ECU: " -NoNewline
        Write-Host ("{0,-6} ({1,-20})" -f $ecuId, $ecuName) -ForegroundColor White -NoNewline
        Write-Host " | Latency:   " -NoNewline
        if ($lat -le 50) {
            Write-Host ("{0,4} ms" -f $lat) -ForegroundColor Green -NoNewline
        } else {
            Write-Host ("{0,4} ms" -f $lat) -ForegroundColor Yellow -NoNewline
        }
        Write-Host " | Packets: TX " -NoNewline
        Write-Host ("{0}" -f $tx) -ForegroundColor Cyan -NoNewline
        Write-Host " / RX " -NoNewline
        Write-Host ("{0}" -f $rx) -ForegroundColor Green

        Write-Host " Protocol:   ISO 15765-4 CAN (500 kbps, 11-bit)         | Auto Flow Control & Reassembly: ACTIVE" -ForegroundColor DarkGray
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor DarkGray

        # 3. Live CAN / UDS Stream
        Write-Host " LIVE CAN / UDS BUS STREAM (Real-Time Diagnostic Traffic):" -ForegroundColor Black -BackgroundColor Gray
        $packets = $data.recentPackets
        $maxLines = 14

        if ($null -eq $packets -or $packets.Count -eq 0) {
            Write-Host "  (Awaiting CAN / UDS diagnostic bus packets...)                                " -ForegroundColor DarkGray
            for ($i = 0; $i -lt ($maxLines - 1); $i++) {
                Write-Host (" " * 80)
            }
        } else {
            $count = [Math]::Min($maxLines, $packets.Count)
            $start = $packets.Count - $count
            for ($i = $start; $i -lt $packets.Count; $i++) {
                $pkt = $packets[$i]
                $padded = "{0,-78}" -f $pkt
                if ($padded.Length -gt 78) { $padded = $padded.Substring(0, 78) }
                if ($pkt -match "TX ->") {
                    Write-Host "  $padded" -ForegroundColor Cyan
                } elseif ($pkt -match "RX <-") {
                    if ($pkt -match "NRC") {
                        Write-Host "  $padded" -ForegroundColor Yellow
                    } else {
                        Write-Host "  $padded" -ForegroundColor Green
                    }
                } else {
                    Write-Host "  $padded" -ForegroundColor White
                }
            }
            # Fill remaining lines up to maxLines
            for ($j = $count; $j -lt $maxLines; $j++) {
                Write-Host (" " * 80)
            }
        }

        Write-Host "================================================================================" -ForegroundColor Cyan
        Write-Host " [Q] Exit Monitor  |  Log: elm327_log.txt  |  Refresh: 8 Hz                     " -ForegroundColor Gray

        if ($SingleShot) {
            break
        }

        Start-Sleep -Milliseconds $RefreshRateMs
    }
} finally {
    if ($hasConsole) {
        try { [Console]::CursorVisible = $true } catch { }
    }
    Write-Host ""
    Write-Host "Live CAN Monitor closed." -ForegroundColor Yellow
}
