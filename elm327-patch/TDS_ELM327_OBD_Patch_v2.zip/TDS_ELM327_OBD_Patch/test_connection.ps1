# =============================================================================
# ELM327 OBD2 PassThru Self-Test Tool (WiFi + USB/Bluetooth)
# =============================================================================
$ErrorActionPreference = "Continue"

Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "      ELM327 OBD2 PassThru Self-Test Diagnostic (WiFi + Serial)   " -ForegroundColor Cyan
Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host ""

$baseDir = $PSScriptRoot
if ([string]::IsNullOrEmpty($baseDir)) { $baseDir = (Get-Location).Path }
$dllPath = Join-Path $baseDir "ELM327_PassThru.dll"
$bridgePath = Join-Path $baseDir "ELM327_Bridge.dll"
$iniPath = Join-Path $baseDir "elm327.ini"

# 1. File verification
Write-Host "[1/4] Checking Driver Files..." -ForegroundColor Yellow
if (Test-Path $dllPath) {
    Write-Host "   [PASS] Found ELM327_PassThru.dll ($(Get-Item $dllPath | Select-Object -ExpandProperty Length) bytes)" -ForegroundColor Green
} else {
    Write-Host "   [FAIL] Missing ELM327_PassThru.dll" -ForegroundColor Red
}

if (Test-Path $bridgePath) {
    Write-Host "   [PASS] Found ELM327_Bridge.dll ($(Get-Item $bridgePath | Select-Object -ExpandProperty Length) bytes)" -ForegroundColor Green
} else {
    Write-Host "   [FAIL] Missing ELM327_Bridge.dll" -ForegroundColor Red
}

# 2. Registry verification
Write-Host ""
Write-Host "[2/4] Checking Windows Registry J2534 Registration..." -ForegroundColor Yellow
$reg32 = "HKLM:\SOFTWARE\WOW6432Node\PassThruSupport.04.04\ELM327 PassThru"
$reg64 = "HKLM:\SOFTWARE\PassThruSupport.04.04\ELM327 PassThru"

if (Test-Path $reg32) {
    $val = Get-ItemProperty $reg32
    Write-Host "   [PASS] Registered in 32-bit hive: $($val.Name)" -ForegroundColor Green
    Write-Host "          FunctionLibrary: $($val.FunctionLibrary)" -ForegroundColor Gray
} else {
    Write-Host "   [FAIL] Not registered in 32-bit registry hive!" -ForegroundColor Red
}

# 3. Hardware Adapter Detection (WiFi & Serial)
Write-Host ""
Write-Host "[3/4] Checking Hardware Adapter Connectivity (WiFi & Serial)..." -ForegroundColor Yellow

$wifiIp = "192.168.0.10"
$wifiPort = 35000
$wifiFound = $false
try {
    $client = New-Object System.Net.Sockets.TcpClient
    $ar = $client.BeginConnect($wifiIp, $wifiPort, $null, $null)
    $ok = $ar.AsyncWaitHandle.WaitOne(600)
    if ($ok -and $client.Connected) {
        $client.EndConnect($ar)
        $client.Close()
        $wifiFound = $true
        Write-Host "   [PASS] WiFi ELM327 adapter detected at ${wifiIp}:${wifiPort}!" -ForegroundColor Green
    } else {
        $client.Close()
    }
} catch { }

if (-not $wifiFound) {
    Write-Host "   [INFO] WiFi ELM327 not reachable at ${wifiIp}:${wifiPort} (connect to adapter WiFi if using WiFi)." -ForegroundColor DarkGray
}

$ports = [System.IO.Ports.SerialPort]::GetPortNames()
if ($ports.Count -gt 0) {
    Write-Host "   [INFO] Detected Serial COM ports: $($ports -join ', ')" -ForegroundColor Cyan
} else {
    Write-Host "   [INFO] No USB/Bluetooth Serial COM ports found." -ForegroundColor DarkGray
}

if ($wifiFound -or $ports.Count -gt 0) {
    Write-Host "   [PASS] At least one ELM327 communication interface is ready." -ForegroundColor Green
} else {
    Write-Host "   [WARN] Neither WiFi ELM327 nor USB COM port detected. Connect to adapter WiFi AP or plug in USB cable." -ForegroundColor Yellow
}

# 4. Configuration Check
Write-Host ""
Write-Host "[4/4] Checking Configuration (elm327.ini)..." -ForegroundColor Yellow
if (Test-Path $iniPath) {
    Get-Content $iniPath | Where-Object { $_ -match "^[A-Z]" } | ForEach-Object {
        Write-Host "   Config: $_" -ForegroundColor Gray
    }
} else {
    Write-Host "   [INFO] Using default configuration (AUTO mode: WiFi 192.168.0.10:35000 + Serial)." -ForegroundColor Gray
}

Write-Host ""
Write-Host "==================================================================" -ForegroundColor Cyan
Write-Host "Self-test finished. If all checks passed, your system is ready!" -ForegroundColor Green
Write-Host "==================================================================" -ForegroundColor Cyan
