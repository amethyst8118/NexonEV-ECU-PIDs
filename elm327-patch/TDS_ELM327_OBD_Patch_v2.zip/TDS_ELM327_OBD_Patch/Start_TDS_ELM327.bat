@echo off
setlocal
title Tata Diagnostic System - ELM327 OBD2 Launcher & Telematics
color 0A

echo =====================================================================
echo    Tata Diagnostic System (TDS) - ELM327 WiFi / USB Launcher
echo =====================================================================
echo.

cd /d "%~dp0"

echo [1/3] Checking J2534 PassThru Driver Registration...
powershell -ExecutionPolicy Bypass -Command "if (Test-Path 'HKLM:\SOFTWARE\WOW6432Node\PassThruSupport.04.04\ELM327 PassThru') { Write-Host '      [OK] ELM327 OBD2 PassThru is registered.' -ForegroundColor Green } else { Write-Host '      [!] Not registered. Running registration...' -ForegroundColor Yellow; & '%~dp0register_elm327_j2534.ps1' }"

echo.
echo [2/3] Checking Adapter Configuration (elm327.ini)...
powershell -ExecutionPolicy Bypass -Command "if (Test-Path '%~dp0elm327.ini') { $c = Get-Content '%~dp0elm327.ini'; $t = ($c | Select-String '^TYPE=').ToString().Split('=')[1].Trim(); $p = ($c | Select-String '^PORT=').ToString().Split('=')[1].Trim(); $w = ($c | Select-String '^WIFI_IP=').ToString().Split('=')[1].Trim() + ':' + ($c | Select-String '^WIFI_PORT=').ToString().Split('=')[1].Trim(); Write-Host '      Mode: ' $t ' | Serial: ' $p ' | WiFi: ' $w -ForegroundColor Cyan } else { Write-Host '      Using default AUTO mode (WiFi 192.168.0.10:35000 + Serial).' -ForegroundColor Gray }"

echo.
echo [3/3] Launching Tata Diagnostic System...
if exist "%~dp0TDS_PassangerCars.exe" (
    start "" "%~dp0TDS_PassangerCars.exe"
    echo       Launched TDS_PassangerCars.exe
) else if exist "%~dp0Extracted\UniversalDiagnosticTool.exe" (
    start "" "%~dp0Extracted\UniversalDiagnosticTool.exe"
    echo       Launched Extracted\UniversalDiagnosticTool.exe
) else (
    echo [ERROR] No TDS executable found in "%~dp0".
    pause
    exit /b 1
)

echo.
echo Starting Live Vehicle Telematics Monitor on this console...
timeout /t 2 /nobreak >nul

powershell -ExecutionPolicy Bypass -File "%~dp0Live_Telematics.ps1"

pause
