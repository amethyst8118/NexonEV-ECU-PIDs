@echo off
setlocal enabledelayedexpansion
title Tata Diagnostic System - ELM327 OBD2 Patch v2 Installer
color 0B

set "PATCH_VER=2.0"

echo =====================================================================
echo    TATA DIAGNOSTIC SYSTEM (TDS) - ELM327 OBD2 PATCH  v%PATCH_VER%
echo =====================================================================
echo.
echo  Upgrades cleanly over v1. Every installed file is replaced, existing
echo  files are backed up first, and your elm327.ini settings are kept.
echo.

:: ---- Administrator ------------------------------------------------------
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Administrator privileges required. Requesting elevation...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

set "PATCH_DIR=%~dp0"
if "%PATCH_DIR:~-1%"=="\" set "PATCH_DIR=%PATCH_DIR:~0,-1%"

:: ---- Locate TDS ---------------------------------------------------------
set "TARGET_DIR="
if exist "%PATCH_DIR%\TDS_PassangerCars.exe" (
    set "TARGET_DIR=%PATCH_DIR%"
) else if exist "%PATCH_DIR%\..\TDS_PassangerCars.exe" (
    pushd "%PATCH_DIR%\.." & set "TARGET_DIR=!CD!" & popd
)
if "%TARGET_DIR%"=="" (
    if exist "C:\Program Files (x86)\TATA_Diagnostic_Passenger_Cars_20.0.0\TDS_PassangerCars.exe" (
        set "TARGET_DIR=C:\Program Files (x86)\TATA_Diagnostic_Passenger_Cars_20.0.0"
    ) else if exist "C:\Program Files\TATA_Diagnostic_Passenger_Cars_20.0.0\TDS_PassangerCars.exe" (
        set "TARGET_DIR=C:\Program Files\TATA_Diagnostic_Passenger_Cars_20.0.0"
    )
)
if "%TARGET_DIR%"=="" (
    echo TDS installation directory was not detected automatically.
    set /p "TARGET_DIR=Full path to your TDS folder: "
)
if not exist "%TARGET_DIR%\TDS_PassangerCars.exe" (
    echo.
    echo [ERROR] TDS_PassangerCars.exe not found in "%TARGET_DIR%"
    echo Installation aborted - nothing has been changed.
    echo.
    pause
    exit /b 1
)
echo [*] Target: "%TARGET_DIR%"

:: ---- Detect a previous install -----------------------------------------
set "UPGRADE=0"
if exist "%TARGET_DIR%\ELM327_Bridge.dll" set "UPGRADE=1"
if "%UPGRADE%"=="1" (
    echo [*] Existing ELM327 patch detected - performing an upgrade.
) else (
    echo [*] No previous patch found - performing a fresh install.
)

:: ---- Close TDS ----------------------------------------------------------
tasklist /FI "IMAGENAME eq TDS_PassangerCars.exe" 2>nul | findstr /I "TDS_PassangerCars" >nul
if %errorlevel% equ 0 (
    echo [!] TDS is running - closing it so the DLLs can be replaced...
    taskkill /F /IM TDS_PassangerCars.exe >nul 2>&1
    ping 127.0.0.1 -n 4 >nul
)

:: ---- Back up ------------------------------------------------------------
echo.
echo [1/6] Backing up existing files...
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value 2^>nul ^| find "="') do set "DT=%%I"
set "STAMP=%DT:~0,8%_%DT:~8,6%"
set "BACKUP_DIR=%TARGET_DIR%\ELM327_backup_%STAMP%"
mkdir "%BACKUP_DIR%" >nul 2>&1
for %%F in (
    ELM327_Bridge.dll ELM327_Bridge.cs ELM327_PassThru.dll ELM327_PassThru.il
    elm327.ini Start_TDS_ELM327.bat Test_OBD_Connection.bat test_connection.ps1
    Live_Telematics.bat Live_Telematics.ps1 register_elm327_j2534.ps1
) do (
    if exist "%TARGET_DIR%\%%F" copy /y "%TARGET_DIR%\%%F" "%BACKUP_DIR%\%%F" >nul 2>&1
)
echo       Saved to: ELM327_backup_%STAMP%

:: ---- Install ------------------------------------------------------------
echo.
echo [2/6] Installing patch files...
for %%F in (
    ELM327_Bridge.dll ELM327_Bridge.cs ELM327_PassThru.dll ELM327_PassThru.reg
    Start_TDS_ELM327.bat Test_OBD_Connection.bat test_connection.ps1
    Live_Telematics.bat Live_Telematics.ps1 register_elm327_j2534.ps1
    merge_ini.ps1 ANALYSIS.md
) do (
    if exist "%PATCH_DIR%\%%F" (
        copy /y "%PATCH_DIR%\%%F" "%TARGET_DIR%\%%F" >nul
        if errorlevel 1 (
            echo       [FAIL] %%F could not be copied - is TDS still running?
        ) else (
            echo       [ok] %%F
        )
    )
)

:: The unpacked copy, if the VFS was extracted, must match or TDS may load the
:: stale bridge from there.
if exist "%TARGET_DIR%\Extracted\" (
    echo.
    echo [3/6] Updating Extracted\ copies...
    for %%F in (ELM327_Bridge.dll ELM327_PassThru.dll) do (
        if exist "%PATCH_DIR%\%%F" copy /y "%PATCH_DIR%\%%F" "%TARGET_DIR%\Extracted\%%F" >nul
    )
    if exist "%TARGET_DIR%\elm327.ini" copy /y "%TARGET_DIR%\elm327.ini" "%TARGET_DIR%\Extracted\elm327.ini" >nul
    echo       Extracted\ synchronised.
) else (
    echo.
    echo [3/6] No Extracted\ folder - skipping.
)

:: ---- Merge configuration ------------------------------------------------
echo.
echo [4/6] Merging elm327.ini...
powershell -ExecutionPolicy Bypass -File "%PATCH_DIR%\merge_ini.ps1" -Existing "%TARGET_DIR%\elm327.ini" -Template "%PATCH_DIR%\elm327.ini"
if exist "%TARGET_DIR%\Extracted\" copy /y "%TARGET_DIR%\elm327.ini" "%TARGET_DIR%\Extracted\elm327.ini" >nul 2>&1

:: ---- Register + shortcut ------------------------------------------------
echo.
echo [5/6] Registering SAE J2534 PassThru driver...
powershell -ExecutionPolicy Bypass -File "%PATCH_DIR%\register_elm327_j2534.ps1" -TargetDir "%TARGET_DIR%"

powershell -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $d = [Environment]::GetFolderPath('Desktop'); $sc = $ws.CreateShortcut((Join-Path $d 'Launch_TDS_ELM327.lnk')); $sc.TargetPath = (Join-Path '%TARGET_DIR%' 'Start_TDS_ELM327.bat'); $sc.WorkingDirectory = '%TARGET_DIR%'; $sc.Description = 'Launch Tata Diagnostic System with ELM327 OBD2'; $ico = (Join-Path '%TARGET_DIR%' 'TDS_PassangerCars.exe'); if (Test-Path $ico) { $sc.IconLocation = $ico + ',0' }; $sc.Save(); Write-Host '      Desktop shortcut refreshed.' -ForegroundColor Green"

:: ---- Verify -------------------------------------------------------------
echo.
echo [6/6] Verifying...
set "FAILED=0"
for %%F in (ELM327_Bridge.dll ELM327_PassThru.dll elm327.ini) do (
    if exist "%TARGET_DIR%\%%F" ( echo       [OK] %%F ) else ( echo       [MISSING] %%F & set "FAILED=1" )
)
findstr /I /C:"ACCEPT_ALL_RESPONDERS" "%TARGET_DIR%\elm327.ini" >nul 2>&1
if errorlevel 1 ( echo       [WARN] elm327.ini is missing the v2 keys. ) else ( echo       [OK] v2 configuration keys present. )
echo %PATCH_VER% > "%TARGET_DIR%\ELM327_patch_version.txt"

echo.
if "%FAILED%"=="1" (
    color 0C
    echo =====================================================================
    echo   PATCH INCOMPLETE - see [MISSING] above.
    echo   Your originals are in: ELM327_backup_%STAMP%
    echo =====================================================================
) else (
    echo =====================================================================
    echo                  PATCH v%PATCH_VER% APPLIED SUCCESSFULLY
    echo =====================================================================
    echo.
    echo  What changed in v2:
    echo   - header and reassembly state no longer survive a reconnect
    echo   - serial write timeout raised 400ms to 2000ms
    echo   - input buffer no longer flushed mid multi-frame
    echo   - ATZ given 3000ms so the version banner is not truncated
    echo   - responses checked against the addressed ECU before being queued
    echo   - elm327_log.txt now rotates instead of growing without limit
    echo.
    echo  Launch with the 'Launch_TDS_ELM327' desktop shortcut.
    echo  Settings: "%TARGET_DIR%\elm327.ini"
    echo  Rollback: copy the files from ELM327_backup_%STAMP% back over.
)
echo.
pause
