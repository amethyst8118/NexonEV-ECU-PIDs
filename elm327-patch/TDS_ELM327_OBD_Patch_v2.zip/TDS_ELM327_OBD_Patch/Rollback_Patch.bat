@echo off
setlocal enabledelayedexpansion
title TDS ELM327 Patch - Rollback
color 0E

echo =====================================================================
echo        TDS ELM327 OBD2 PATCH - ROLLBACK TO A PREVIOUS BACKUP
echo =====================================================================
echo.

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [!] Administrator privileges required. Requesting elevation...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

set "TARGET_DIR=%~dp0"
if "%TARGET_DIR:~-1%"=="\" set "TARGET_DIR=%TARGET_DIR:~0,-1%"
if not exist "%TARGET_DIR%\TDS_PassangerCars.exe" (
    if exist "%TARGET_DIR%\..\TDS_PassangerCars.exe" (
        pushd "%TARGET_DIR%\.." & set "TARGET_DIR=!CD!" & popd
    ) else if exist "C:\Program Files (x86)\TATA_Diagnostic_Passenger_Cars_20.0.0\TDS_PassangerCars.exe" (
        set "TARGET_DIR=C:\Program Files (x86)\TATA_Diagnostic_Passenger_Cars_20.0.0"
    )
)
if not exist "%TARGET_DIR%\TDS_PassangerCars.exe" (
    echo [ERROR] TDS folder not found. Run this from inside the TDS directory.
    pause & exit /b 1
)

echo [*] TDS folder: "%TARGET_DIR%"
echo.
echo Available backups:
set "N=0"
for /f "delims=" %%D in ('dir /b /ad /o-n "%TARGET_DIR%\ELM327_backup_*" 2^>nul') do (
    set /a N+=1
    set "B!N!=%%D"
    echo    !N!^) %%D
)
if "%N%"=="0" (
    echo    (none found - nothing to roll back to^)
    echo.
    pause & exit /b 1
)
echo.
set /p "SEL=Enter the number to restore (or press Enter to cancel): "
if "%SEL%"=="" echo Cancelled. & pause & exit /b 0
set "CHOSEN=!B%SEL%!"
if "%CHOSEN%"=="" echo Invalid selection. & pause & exit /b 1

echo.
echo [*] Restoring from %CHOSEN% ...
tasklist /FI "IMAGENAME eq TDS_PassangerCars.exe" 2>nul | findstr /I "TDS_PassangerCars" >nul
if %errorlevel% equ 0 (
    echo [!] Closing TDS...
    taskkill /F /IM TDS_PassangerCars.exe >nul 2>&1
    ping 127.0.0.1 -n 4 >nul
)

for %%F in ("%TARGET_DIR%\%CHOSEN%\*") do (
    copy /y "%%F" "%TARGET_DIR%\%%~nxF" >nul
    echo       restored %%~nxF
    if exist "%TARGET_DIR%\Extracted\%%~nxF" copy /y "%%F" "%TARGET_DIR%\Extracted\%%~nxF" >nul
)

del "%TARGET_DIR%\ELM327_patch_version.txt" >nul 2>&1
echo.
echo =====================================================================
echo   Rollback complete. The backup folder has been left in place.
echo =====================================================================
echo.
pause
