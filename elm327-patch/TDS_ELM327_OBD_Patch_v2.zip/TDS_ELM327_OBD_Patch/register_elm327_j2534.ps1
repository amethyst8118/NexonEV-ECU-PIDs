# =============================================================================
# Register ELM327 J2534 PassThru Driver for Tata Diagnostic System (TDS)
# Portable Registration Script
# =============================================================================
param (
    [string]$TargetDir = $PSScriptRoot
)

if (-not (Test-Path $TargetDir)) {
    $TargetDir = $PSScriptRoot
}

$dllPath = Join-Path $TargetDir "ELM327_PassThru.dll"
$iniPath = Join-Path $TargetDir "elm327.ini"

if (-not (Test-Path $dllPath)) {
    Write-Host "ERROR: ELM327_PassThru.dll not found in $TargetDir" -ForegroundColor Red
    exit 1
}

$regHives = @(
    "HKLM:\SOFTWARE\WOW6432Node\PassThruSupport.04.04\ELM327 PassThru",
    "HKLM:\SOFTWARE\PassThruSupport.04.04\ELM327 PassThru"
)

foreach ($hive in $regHives) {
    try {
        if (!(Test-Path $hive)) {
            New-Item -Path $hive -Force | Out-Null
        }

        Set-ItemProperty -Path $hive -Name "Vendor" -Value "ELM327" -Type String
        Set-ItemProperty -Path $hive -Name "Name" -Value "ELM327 OBD2 PassThru" -Type String
        Set-ItemProperty -Path $hive -Name "FunctionLibrary" -Value $dllPath -Type String
        Set-ItemProperty -Path $hive -Name "ConfigApplication" -Value $iniPath -Type String
        Set-ItemProperty -Path $hive -Name "CAN" -Value 1 -Type DWord
        Set-ItemProperty -Path $hive -Name "ISO15765" -Value 1 -Type DWord
        Set-ItemProperty -Path $hive -Name "ISO14230" -Value 1 -Type DWord
        Set-ItemProperty -Path $hive -Name "ISO9141" -Value 1 -Type DWord
        Set-ItemProperty -Path $hive -Name "J1850PWM" -Value 0 -Type DWord
        Set-ItemProperty -Path $hive -Name "J1850VPW" -Value 0 -Type DWord

        Write-Host "Successfully registered ELM327 PassThru in: $hive" -ForegroundColor Green
    } catch {
        Write-Host "Warning: Failed to register in $hive : $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

Write-Host "J2534 PassThru registration completed successfully." -ForegroundColor Cyan
