@echo off
title Tata Diagnostic System - Live Telematics Monitor
mode con: cols=84 lines=32
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "%~dp0Live_Telematics.ps1"
pause
