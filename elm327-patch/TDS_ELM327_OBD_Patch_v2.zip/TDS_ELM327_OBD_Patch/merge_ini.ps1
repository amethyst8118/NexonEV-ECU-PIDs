# Merge elm327.ini so an upgrade keeps the user's settings.
#
# v1 of this patch overwrote elm327.ini outright, silently resetting PORT, BAUD,
# TYPE and the WiFi settings back to defaults. This keeps every value already
# present and only appends keys that did not exist before.

param(
    [Parameter(Mandatory = $true)][string]$Existing,
    [Parameter(Mandatory = $true)][string]$Template
)

function Get-IniKeys([string]$path) {
    $keys = @{}
    if (-not (Test-Path $path)) { return $keys }
    foreach ($line in (Get-Content -LiteralPath $path)) {
        $t = $line.Trim()
        if ($t -eq '' -or $t.StartsWith(';') -or $t.StartsWith('#') -or $t.StartsWith('[')) { continue }
        $eq = $t.IndexOf('=')
        if ($eq -gt 0) {
            $k = $t.Substring(0, $eq).Trim().ToUpperInvariant()
            $keys[$k] = $t.Substring($eq + 1).Trim()
        }
    }
    return $keys
}

if (-not (Test-Path $Existing)) {
    Copy-Item -LiteralPath $Template -Destination $Existing -Force
    Write-Host "      elm327.ini created from template." -ForegroundColor Green
    exit 0
}

$old = Get-IniKeys $Existing
$new = Get-IniKeys $Template

# Rewrite the template, substituting any value the user had already set.
$out = New-Object System.Collections.Generic.List[string]
$seen = @{}
foreach ($line in (Get-Content -LiteralPath $Template)) {
    $t = $line.Trim()
    if ($t -ne '' -and -not $t.StartsWith(';') -and -not $t.StartsWith('#') -and -not $t.StartsWith('[')) {
        $eq = $t.IndexOf('=')
        if ($eq -gt 0) {
            $k = $t.Substring(0, $eq).Trim()
            $ku = $k.ToUpperInvariant()
            $seen[$ku] = $true
            if ($old.ContainsKey($ku)) {
                $out.Add("$k=$($old[$ku])")
                continue
            }
        }
    }
    $out.Add($line)
}

# Anything the user added that the template does not know about is preserved.
$extra = @()
foreach ($k in $old.Keys) { if (-not $seen.ContainsKey($k)) { $extra += "$k=$($old[$k])" } }
if ($extra.Count -gt 0) {
    $out.Add("")
    $out.Add("; ---- settings carried over from your previous elm327.ini ----")
    foreach ($e in $extra) { $out.Add($e) }
}

# Write without a BOM. PowerShell 5's -Encoding UTF8 prepends one, which would
# end up in front of the first line - harmless against a comment, but not if the
# file happens to start with a section header.
$enc = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllLines($Existing, $out, $enc)

$added = @()
foreach ($k in $new.Keys) { if (-not $old.ContainsKey($k)) { $added += $k } }
if ($added.Count -gt 0) {
    Write-Host ("      elm327.ini merged - kept your settings, added: " + ($added -join ', ')) -ForegroundColor Green
} else {
    Write-Host "      elm327.ini merged - all settings preserved." -ForegroundColor Green
}
