@echo off
title ELM327 OBD2 Self-Test
color 0E
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "%~dp0test_connection.ps1"
echo.
pause
